package com.company;

import org.junit.Test;

import static org.junit.Assert.*;

public class PlayerTest {

    @Test
    public void getPlayerWidth() {
        Player player = new Player(150, 15, 150, 0);
        assertEquals(150,player.getSize());
    }


    @Test
    public void testIsScored() {
ScoringSystem scoringSystem= new ScoringSystem();

        Player player1 = new Player(150, 15, 150, 0);
        Player player2 = new Player(150, 15, 100, 300);

assertTrue(scoringSystem.scored(true,14,player1,player2));

    }
}