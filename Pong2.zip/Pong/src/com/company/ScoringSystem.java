package com.company;

public class ScoringSystem {
    int score1 = 0;
    int score2 = 0;


    public boolean scored(boolean gamestarted, double xPos, Player p1, Player p2) {

        boolean rez = gamestarted;
        if (xPos < -p1.getPlayerWidth()) { // score!!
            score2++;
            rez = false;
        }

        // nuo "sienos" atstumiam, nes kitaip uz screen ribu
        if (xPos > p2.getPlayerX() + p2.getPlayerWidth()) {
            score1++; // yaaaay!
            rez = false;
        }

        return rez;


    }


    public int getScore1() {
        return score1;
    }

    public void setScore1(int score1) {
        this.score1 = score1;
    }

    public int getScore2() {
        return score2;
    }

    public void setScore2(int score2) {
        this.score2 = score2;
    }
}
