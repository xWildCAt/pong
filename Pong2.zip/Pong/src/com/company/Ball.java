package com.company;

public class Ball extends Thing {

    private int SpeedY;
    private int SpeedX;
    private double XPos;
    private double YPos;


    public Ball(int size, int speedY, int speedX, double XPos, double YPos) {
        super(size);
        SpeedY = speedY;
        SpeedX = speedX;
        this.XPos = XPos;
        this.YPos = YPos;
    }

    public int getSpeedY() {
        return SpeedY;
    }

    public void setSpeedY(int speedY) {
        SpeedY = speedY;
    }

    public int getSpeedX() {
        return SpeedX;
    }

    public void setSpeedX(int speedX) {
        SpeedX = speedX;
    }

    public double getXPos() {
        return XPos;
    }

    public void setXPos(double XPos) {
        this.XPos = XPos;
    }

    public double getYPos() {
        return YPos;
    }

    public void setYPos(double YPos) {
        this.YPos = YPos;
    }


}
