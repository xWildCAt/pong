package com.company;

public class Player extends Thing {

    private int playerWidth;

    private double playerY;
    private double playerX;


    public Player(int size, int playerWidth, double playerY, double playerX) {
        super(size);
        this.playerWidth = playerWidth;
        this.playerY = playerY;
        this.playerX = playerX;
    }

    public int getPlayerWidth() {
        return playerWidth;
    }

    public void setPlayerWidth(int playerWidth) {
        this.playerWidth = playerWidth;
    }

    public double getPlayerY() {
        return playerY;
    }

    public void setPlayerY(double playerY) {
        this.playerY = playerY;
    }

    public double getPlayerX() {
        return playerX;
    }

    public void setPlayerX(double playerX) {
        this.playerX = playerX;
    }
}
