package com.company;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application {

    private boolean gameStarted;

    private static final int width = 800;
    private static final int height = 600;

    Player player1 = new Player(150, 15, height / 2, 0);
    Player player2 = new Player(150, 15, height / 2, width - 15);
    Ball ball = new Ball(15, 1, 1, 300, 400);
    ScoringSystem scoringSystem = new ScoringSystem();

    public void start(Stage stage) throws Exception {

        Canvas canvas = new Canvas(width, height); //for drawing
        GraphicsContext graphicsContext = canvas.getGraphicsContext2D(); //Each call pushes the necessary parameters onto the buffer where they will be later rendered onto the image of the Canvas node by the rendering thread at the end of a pulse.
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(10), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {//event handler
                Main.this.run(graphicsContext);
            }
        })); //processes individual KeyFrame sequentially

        timeline.setCycleCount(Timeline.INDEFINITE); // runs repeatedly until the stop() method is explicitly called. stopo nera, tai tiesiog be galo :P

        canvas.setOnMouseMoved(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent e) {
                player1.setPlayerY(e.getY() - player1.getSize() / 2);
            }
        }); //player'io control
        canvas.setOnMouseClicked(e -> gameStarted = true);
        stage.setScene(new Scene(new StackPane(canvas)));
        stage.show();


        timeline.play(); // paledziam laika

    }

    private void run(GraphicsContext graphicsContext) {
        graphicsContext.setFill(Color.BLACK);
        graphicsContext.fillRect(0, 0, width, height);
        graphicsContext.setFill(Color.RED);
        graphicsContext.setFont(Font.font(30));


        if (gameStarted) {
            ball.setXPos(ball.getXPos() + ball.getSpeedX());// taip ir judam. kiekviena frame vis pridedam "greiti" prie "vietos"
            ball.setYPos(ball.getYPos() + ball.getSpeedY());
            graphicsContext.fillOval(ball.getXPos(), ball.getYPos(), ball.getSize(), ball.getSize()); // piesiam kamuoli


            player2.setPlayerY(ball.getYPos()); // paprastas variantas, bet uz ekrano ribu labai iseina. ir stengiasi atmust visada su virsutiniu kampu. not good.
            //TODO: parasyti grazesni varianta...


        } else {//pradinis screen, arba kai scorina kazkas
            graphicsContext.setStroke(Color.WHITE);
            graphicsContext.setTextAlign(TextAlignment.CENTER);
            graphicsContext.strokeText("Right Click To Play", 400, 300);
            // per vidury nustatom
            ball.setXPos(400);
            ball.setYPos(300);

            //TODO: Padaryt, kad i random puse pradetu judet is pradziu
            ball.setSpeedX(-1);
            ball.setSpeedY(1);
        }
        if (ball.getYPos() > height || ball.getYPos() < 0)
            ball.setSpeedY(ball.getSpeedY() * -1); // nuo sienu atmusinejam

        gameStarted = scoringSystem.scored(gameStarted, ball.getXPos(), player1, player2);

        //basically, cia mes tikrinam, kad normaliai atsimusinetu.... Lyg tai nebugintas variantas...
        if (((ball.getXPos() + ball.getSize() > player2.getPlayerX()) && ball.getYPos() >= player2.getPlayerY() && ball.getYPos() <= player2.getPlayerY() + player2.getSize()) ||
                ((ball.getXPos() < player1.getPlayerX() + player1.getPlayerWidth()) && ball.getYPos() >= player1.getPlayerY() && ball.getYPos() <= player1.getPlayerY() + player1.getSize())) {
            ball.setSpeedY((int) (ball.getSpeedY() + 1 * Math.signum(ball.getSpeedY()))); //Returns the signum function of the argument; zero if the argument is zero, 1.0 if the argument is greater than zero, -1.0 if the argument is less than zero.
            ball.setSpeedX((int) (ball.getSpeedX() + 1 * Math.signum(ball.getSpeedX()))); // Nice, super patogu signum :D realiai bendras, kad neskaiciuoti, nuo ko atsimusa ir automatiskai apversti jurejimo krypti.
            ball.setSpeedX(ball.getSpeedX() * -1);// revers i kita puse
            ball.setSpeedY(ball.getSpeedY() * -1); // same
        }
        graphicsContext.fillText(scoringSystem.getScore1() + "\t\t\t\t\t\t\t\t" + scoringSystem.getScore2(), width / 2, 100);
        graphicsContext.fillRect(player2.getPlayerX(), player2.getPlayerY(), player2.getPlayerWidth(), player2.getSize());
        graphicsContext.fillRect(player1.getPlayerX(), player1.getPlayerY(), player1.getPlayerWidth(), player1.getSize());
    }

}